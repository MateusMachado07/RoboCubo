// ============================================================
// ROBÔ CUBO — Phase 4: Autopilot
// ============================================================
// The robot drives autonomously, avoiding obstacles.
//
// Algorithm (state machine):
//
//   ┌──────────────────────────────────────────┐
//   │  CLEAR -> obstacle < 35cm -> TURNING    │
//   │  TURNING (random 350-1400ms) -> CLEAR   │
//   └──────────────────────────────────────────┘
//
// On detecting an obstacle, the robot stops, turns a random
// angle (45°-180°, left or right at random) in place, then
// continues forward. No reversing involved.
//
// Uses millis() instead of delay() so the sensor keeps being
// read during turns.
// ============================================================

#define ENA  10
#define IN1  4
#define IN2  5
#define ENB  9
#define IN3  6
#define IN4  7

#define TRIG_PIN  12
#define ECHO_PIN  13   // NOTE: moved to D8 in the final code

#define SPEED_NORMAL  180
#define SPEED_SLOW    110
#define SPEED_TURN    110

#define DIST_STOP  35
#define DIST_SLOW  50

#define TURN_DURATION_45    350
#define TURN_DURATION_MIN   TURN_DURATION_45
#define TURN_DURATION_MAX   (TURN_DURATION_45 * 4)

enum AutoState { CLEAR, TURNING };
AutoState state = CLEAR;

unsigned long startTime = 0;
int turnDuration = 0;
bool turnRight = false;

float readDistance() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  long duration = pulseIn(ECHO_PIN, HIGH, 10000);
  if (duration == 0) return 999.0;
  return duration / 58.0;
}

void stopMotors() {
  digitalWrite(IN1, LOW);  digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW);  digitalWrite(IN4, LOW);
  analogWrite(ENA, 0);     analogWrite(ENB, 0);
}

void goForward(int vel) {
  digitalWrite(IN1, HIGH); digitalWrite(IN2, LOW);
  digitalWrite(IN3, HIGH); digitalWrite(IN4, LOW);
  analogWrite(ENA, vel);   analogWrite(ENB, vel);
}

void turnLeftFn(int vel) {
  digitalWrite(IN1, LOW);  digitalWrite(IN2, HIGH);
  digitalWrite(IN3, HIGH); digitalWrite(IN4, LOW);
  analogWrite(ENA, vel);   analogWrite(ENB, vel);
}

void turnRightFn(int vel) {
  digitalWrite(IN1, HIGH); digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW);  digitalWrite(IN4, HIGH);
  analogWrite(ENA, vel);   analogWrite(ENB, vel);
}

void autopilot(float distance) {
  unsigned long now = millis();

  switch (state) {

    case CLEAR:
      if (distance < DIST_STOP) {
        stopMotors();
        startTime    = now;
        turnRight    = random(2);
        turnDuration = random(TURN_DURATION_MIN, TURN_DURATION_MAX + 1);

        state = TURNING;
        Serial.print("OBSTACLE -> TURNING ");
        Serial.print(turnRight ? "RIGHT" : "LEFT");
        Serial.print(" (~");
        Serial.print(map(turnDuration, TURN_DURATION_MIN, TURN_DURATION_MAX, 45, 180));
        Serial.println(" deg)");

      } else if (distance < DIST_SLOW) {
        goForward(SPEED_SLOW);

      } else {
        goForward(SPEED_NORMAL);
      }
      break;

    case TURNING:
      if (turnRight) {
        turnRightFn(SPEED_TURN);
      } else {
        turnLeftFn(SPEED_TURN);
      }

      if (now - startTime >= turnDuration) {
        stopMotors();
        state = CLEAR;
        Serial.println("CLEAR -> FORWARD");
      }
      break;
  }
}

void setup() {
  pinMode(ENA, OUTPUT); pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  pinMode(ENB, OUTPUT); pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  randomSeed(analogRead(A0));

  Serial.begin(9600);
  Serial.println("================================");
  Serial.println(" Robo Cubo — Phase 4: Autopilot");
  Serial.println("================================");
  delay(3000);
  Serial.println("GO!");
}

void loop() {
  float distance = readDistance();
  autopilot(distance);
  delay(50);
}
