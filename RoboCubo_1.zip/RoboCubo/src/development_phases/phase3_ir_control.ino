// ============================================================
// ROBÔ CUBO — Phase 3: IR Remote Control
// ============================================================
// Manual control via IR remote, with automatic obstacle stop.
// ============================================================

#include <IRremote.hpp>

#define ENA  10
#define IN1  4
#define IN2  5
#define ENB  9
#define IN3  6
#define IN4  7

#define TRIG_PIN  12
#define ECHO_PIN  13   // NOTE: moved to D8 in the final code

#define IR_PIN  2

#define DIST_STOP  20
#define DIST_SLOW  35

#define SPEED_MAX     220
#define SPEED_MIN     100
#define SPEED_STEP     20
#define SPEED_TURN    110   // fixed speed used while turning

#define BTN_FORWARD     0x18
#define BTN_BACKWARD    0x52
#define BTN_LEFT        0x08
#define BTN_RIGHT       0x5A
#define BTN_STOP        0x1C
#define BTN_SPEED_UP    0x09
#define BTN_SPEED_DOWN  0x07
#define BTN_STOP_ALL    0x45

int speed = 180;

enum Movement { STOPPED, FORWARD, BACKWARD, LEFT, RIGHT };
Movement currentMovement = STOPPED;

float readDistance() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  long duration = pulseIn(ECHO_PIN, HIGH, 10000);
  if (duration == 0) return 999.0;
  return duration / 58.0;
}

void stopMotors() {
  digitalWrite(IN1, LOW);  digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW);  digitalWrite(IN4, LOW);
  analogWrite(ENA, 0);     analogWrite(ENB, 0);
}

// NOTE: direction logic below reflects the mapping confirmed
// by physical testing — see docs/issues-resolved.md
void goForward(int vel) {
  digitalWrite(IN1, LOW);  digitalWrite(IN2, HIGH);
  digitalWrite(IN3, HIGH); digitalWrite(IN4, LOW);
  analogWrite(ENA, vel);   analogWrite(ENB, vel);
}

void goBackward(int vel) {
  digitalWrite(IN1, HIGH); digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW);  digitalWrite(IN4, HIGH);
  analogWrite(ENA, vel);   analogWrite(ENB, vel);
}

void turnLeft(int vel) {
  digitalWrite(IN1, LOW);  digitalWrite(IN2, HIGH);
  digitalWrite(IN3, LOW);  digitalWrite(IN4, HIGH);
  analogWrite(ENA, vel);   analogWrite(ENB, vel);
}

void turnRight(int vel) {
  digitalWrite(IN1, HIGH); digitalWrite(IN2, LOW);
  digitalWrite(IN3, HIGH); digitalWrite(IN4, LOW);
  analogWrite(ENA, vel);   analogWrite(ENB, vel);
}

void processIR(uint8_t code) {
  switch (code) {
    case BTN_FORWARD:
      currentMovement = FORWARD;
      Serial.print(">> FORWARD | speed: ");
      Serial.println(speed);
      break;

    case BTN_BACKWARD:
      currentMovement = BACKWARD;
      Serial.print(">> BACKWARD | speed: ");
      Serial.println(speed);
      break;

    case BTN_LEFT:
      currentMovement = LEFT;
      Serial.print(">> LEFT | fixed speed: ");
      Serial.println(SPEED_TURN);
      break;

    case BTN_RIGHT:
      currentMovement = RIGHT;
      Serial.print(">> RIGHT | fixed speed: ");
      Serial.println(SPEED_TURN);
      break;

    case BTN_STOP:
    case BTN_STOP_ALL:
      currentMovement = STOPPED;
      Serial.println(">> STOP");
      break;

    case BTN_SPEED_UP:
      speed = min(speed + SPEED_STEP, SPEED_MAX);
      Serial.print(">> SPEED+ -> ");
      Serial.println(speed);
      break;

    case BTN_SPEED_DOWN:
      speed = max(speed - SPEED_STEP, SPEED_MIN);
      Serial.print(">> SPEED- -> ");
      Serial.println(speed);
      break;

    default:
      Serial.print("   unknown code: 0x");
      Serial.println(code, HEX);
      break;
  }
}

void applyMovement(float distance) {
  if (distance < DIST_STOP && currentMovement == FORWARD) {
    stopMotors();
    return;
  }

  switch (currentMovement) {
    case STOPPED:  stopMotors();            break;
    case FORWARD:  goForward(speed);        break;
    case BACKWARD: goBackward(speed);       break;
    case LEFT:     turnLeft(SPEED_TURN);    break;
    case RIGHT:    turnRight(SPEED_TURN);   break;
  }
}

void setup() {
  pinMode(ENA, OUTPUT); pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  pinMode(ENB, OUTPUT); pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  IrReceiver.begin(IR_PIN, DISABLE_LED_FEEDBACK);

  Serial.begin(9600);
  Serial.println("================================");
  Serial.println(" Robo Cubo — Phase 3: IR Control");
  Serial.println("================================");
}

void loop() {
  float distance = readDistance();

  if (IrReceiver.decode()) {
    uint8_t code  = IrReceiver.decodedIRData.command;
    uint8_t flags = IrReceiver.decodedIRData.flags;
    if (code != 0 && !(flags & IRDATA_FLAGS_IS_REPEAT)) {
      processIR(code);
    }
    IrReceiver.resume();
  }

  applyMovement(distance);

  delay(20);
}
