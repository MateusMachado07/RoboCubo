// ============================================================
// ROBÔ CUBO — Phase 2: Ultrasonic Sensor + Automatic Stop
// ============================================================
// Goal: read distance with the HC-SR04 and automatically stop
// the robot as it approaches an obstacle.
// ============================================================

#define ENA  10
#define IN1  4
#define IN2  5
#define ENB  9
#define IN3  6
#define IN4  7

#define TRIG_PIN  12
#define ECHO_PIN  13   // NOTE: in the final code this moves to D8

#define SPEED_NORMAL  180
#define SPEED_SLOW    110

#define DIST_STOP  20
#define DIST_SLOW  35

float readDistance() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  long duration = pulseIn(ECHO_PIN, HIGH, 30000);
  if (duration == 0) return 999.0;
  return duration / 58.0;
}

void stopMotors() {
  digitalWrite(IN1, LOW);  digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW);  digitalWrite(IN4, LOW);
  analogWrite(ENA, 0);     analogWrite(ENB, 0);
}

void goForward(int vel) {
  digitalWrite(IN1, HIGH); digitalWrite(IN2, LOW);
  digitalWrite(IN3, HIGH); digitalWrite(IN4, LOW);
  analogWrite(ENA, vel);   analogWrite(ENB, vel);
}

void setup() {
  pinMode(ENA, OUTPUT); pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  pinMode(ENB, OUTPUT); pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  Serial.begin(9600);
  Serial.println("================================");
  Serial.println(" Robo Cubo — Phase 2: HC-SR04");
  Serial.println("================================");
}

void loop() {
  float distance = readDistance();

  Serial.print("Distance: ");
  if (distance >= 999.0) {
    Serial.println("--- cm | CLEAR (no obstacle)");
  } else {
    Serial.print(distance, 1);
    Serial.print(" cm | ");

    if (distance < DIST_STOP) {
      Serial.println("STOP <<< OBSTACLE NEARBY!");
    } else if (distance < DIST_SLOW) {
      Serial.println("SLOW (warning zone)");
    } else {
      Serial.println("CLEAR — normal speed");
    }
  }

  if (distance < DIST_STOP) {
    stopMotors();
  } else if (distance < DIST_SLOW) {
    goForward(SPEED_SLOW);
  } else {
    goForward(SPEED_NORMAL);
  }

  delay(100);
}
