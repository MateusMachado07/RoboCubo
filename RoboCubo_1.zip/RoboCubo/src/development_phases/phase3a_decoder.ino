// ============================================================
// ROBÔ CUBO — Phase 3a: IR Decoder
// ============================================================
// Goal: identify the codes for each button on the ELEGOO
// remote before programming full control.
//
// How to use:
// 1. Upload this code to the Arduino
// 2. Open the Serial Monitor at 9600 baud
// 3. Point the remote at the receiver and press each button
// 4. Note the code shown for each button
// ============================================================

#include <IRremote.hpp>

#define IR_PIN  2

void setup() {
  Serial.begin(9600);
  IrReceiver.begin(IR_PIN, DISABLE_LED_FEEDBACK);

  Serial.println("================================");
  Serial.println(" Robo Cubo — Phase 3a: Decoder");
  Serial.println("================================");
  Serial.println("Point the remote and press");
  Serial.println("each button...");
}

void loop() {
  if (IrReceiver.decode()) {
    uint32_t rawCode = IrReceiver.decodedIRData.decodedRawData;
    uint8_t  command = IrReceiver.decodedIRData.command;

    if (rawCode != 0xFFFFFFFF && rawCode != 0) {
      Serial.print("Button pressed -> raw: 0x");
      Serial.print(rawCode, HEX);
      Serial.print("  command: 0x");
      Serial.println(command, HEX);
    }

    IrReceiver.resume();
  }
}
